
#include <stdint.h>
#include <stddef.h>
#include <ti/drivers/UART2.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>
#include <stdio.h>





//variables status
int tempChange = 0;
int setpoint = 25; //set to this number for quick test
int heat = 0;
int addone = 1; //not needed but i was aving issues with int and uint16_t
int ledStatus = 0;
int seconds;
int temperature = 0;
//char buffer[50];
char input;
char output[64];
int status;
size_t bytesWritten;
size_t bytesRead;
size_t bytesToSend;
size_t sizething;
uint8_t buffer[64];
int timerFlag = 0;

#define DISPLAY(x) UART2_write(uart, &output, 1, x);



//UART redone using UART2
UART2_Handle uart;
void initUART(){
    UART2_Params params;
    // Initialize UART2 parameters
    UART2_Params_init(&params);
    params.baudRate = 115200;
    params.readMode = UART2_Mode_BLOCKING;
    params.writeMode = UART2_Mode_BLOCKING;
    // Open the UART
    uart = UART2_open(CONFIG_UART2_0, &params);
    if (uart == NULL) {
        // UART2_open() failed
        while (1);
    }
    // Loop forever echoing
    /*
     * while (1) {
        status = UART2_read(uart, &input, 1, &bytesRead);
        status = UART2_write(uart, &input, 1, &bytesWritten);
    }
    */
}
//all DISPLAY functions have been commented out since they did not properly function.
//DISPLAY(snprintf(output, 64, "a\n"))



// I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}

sensors[3] = {
    { 0x48, 0x0000, "11X" },
    { 0x49, 0x0000, "116" },
    { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

// Driver Handles - Global variables
I2C_Handle i2c;


// Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    //DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))
    //DISPLAY(snprintf(buffer, max_len, writeUART("Initializing I2C Driver - ")))
    //UART2_write(uart, buffer, max_len, &"Initializing I2C Driver - ");
    // Init the driver
    I2C_init();
    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;
    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);

    if (i2c == NULL)
    {
        //DISPLAY(snprintf(output, 64, "Failed\n\r"))
        //DISPLAY(snprintf(buffer, max_len, "Failed\n\r"))
        while (1);
    }
    //DISPLAY(snprintf(output, 32, "Passed\n\r"))
    //DISPLAY(snprintf(buffer, max_len, "Passed\n\r"))

    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;
    for (i=0; i<3; ++i)
    {
        i2cTransaction.targetAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        //DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))
        //DISPLAY(snprintf(buffer, max_len, "Is this %s? ", sensors[i].id))

        if (I2C_transfer(i2c, &i2cTransaction))
        {
            //DISPLAY(snprintf(output, 64, "Found\n\r"))
            //DISPLAY(snprintf(buffer, max_len, "Found\n\r"))

            found = true;
            break;
        }
        //DISPLAY(snprintf(output, 64, "No\n\r"))
        //DISPLAY(snprintf(buffer, max_len, "No\n\r"))
    }

    if(found)
    {
        //DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.targetAddress))
        //DISPLAY(snprintf(buffer, max_len, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.targetAddress))
    }
    else
    {
        //DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
        //DISPLAY(snprintf(buffer, max_len, "Temperature sensor not found, contact professor\n\r"))
    }
}













//temperature reading function
int16_t readTemp(void) {
    int j;
    int temperature = 0;
    i2cTransaction.readCount = 2;
    if (I2C_transfer(i2c, &i2cTransaction))
    {
        /*
        * Extract degrees C from the received data;
        * see TMP sensor datasheet
        */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;
        /*
        * If the MSB is set '1', then we have a 2's complement
        * negative value which needs to be sign extended
        */
        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;
        }
    }
    else
    {
        //DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))
        //DISPLAY(snprintf(buffer, max_len, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))

        //DISPLAY(snprintf(output, 64, "PC your board by unplugging USB and plugging back.\n\r"))
        //DISPLAY(snprintf(buffer, max_len, "PC your board by unplugging USB and plugging back.\n\r"))

    }
    return temperature;
}

























//volatile unsigned char TimerFlag = 0;

void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
//    ++timerFlag;
    timerFlag++;

}
//timer init
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    // Init the driver
    Timer_init();
    // Configure the driver
    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    //params.timerMode = Timer_ONESHOT_BLOCKING;
    params.timerCallback = timerCallback;
    // Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1){}
    }
}






//button callback functions
void gpioButtonFxn0(uint_least8_t index)
{
    /* Toggle an LED */
    //GPIO_toggle(CONFIG_GPIO_LED_0);
    tempChange = tempChange + addone;
    printf("added to temp\n");
    printf("tempchange: %i\n", tempChange);
    printf("setpoint: %i\n", setpoint);
    printf("temperature: %i\n", temperature);

}

void gpioButtonFxn1(uint_least8_t index)
{
    /* Toggle an LED */
    //GPIO_toggle(CONFIG_GPIO_LED_0);
    tempChange = tempChange - addone;
    printf("removed from temp\n");
    printf("tempchange: %i\n", tempChange);
    printf("setpoint: %i\n", setpoint);
    printf("temperature: %i\n", temperature);

}





//main
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    //GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);


    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    //GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    //GPIO_enableInt(CONFIG_GPIO_BUTTON_1);


    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1)
    {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }
    initTimer();
    initUART();
    initI2C();


    while(1){
               if (timerFlag % 2 == 0){
                   temperature = readTemp();
                   //printf("%hu\n", readTemp);
                   setpoint = setpoint + tempChange;
                   tempChange = 0;

                   if (timerFlag % 5 == 0)
                   {
                       temperature = readTemp();
                       if (temperature >= setpoint){
                           GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                           ledStatus = 0;
                           heat = 0;
                       }
                       else {
                           GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
                           ledStatus = 1;
                           heat = 1;
                       }
                   }
                   if (timerFlag % 10 == 0){
                       seconds = (timerFlag)/1000; //each timer flag is worth 100 milliseconds by dividing the timerflag by 100 we get the units in seconds.
                       printf("<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds);
                       fflush(stdout);
                       //I honestly spent far too much time figuring out how to get the DISPLAY() function to work alongside UART2_write() and snprintf()
                       //I did get printf() to work alongside the CIO which was not working and it took me a couple of days to figure out why it did not function at the end of the day idk how it started working
                       //DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds))
                   }
               }
    }





    return (NULL);

}
